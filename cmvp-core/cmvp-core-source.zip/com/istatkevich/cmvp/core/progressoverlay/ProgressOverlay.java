package com.istatkevich.cmvp.core.progressoverlay;

import android.content.Context;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v4.content.ContextCompat;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.istatkevich.cmvp.core.R;

/**
 * Created by i.statkevich on 13.03.2017.
 */

public class ProgressOverlay extends RelativeLayout implements Progress {
    private TextView messageView;

    public ProgressOverlay(Context context) {
        this(context, null);
    }

    public ProgressOverlay(Context context, AttributeSet attrs) {
        this(context, attrs, -1);
    }

    public ProgressOverlay(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public ProgressOverlay(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        init();
    }

    @Override
    public void showProgress() {
        showProgress(null);
    }

    @Override
    public void showProgress(String message) {
        if(TextUtils.isEmpty(message)) {
            hideProgressMessage();
        } else {
            setProgressMessage(message);
        }

        bringToFront();
        setVisibility(VISIBLE);
    }

    @Override
    public void hideProgress() {
        setVisibility(GONE);
    }

    @Override
    public void setProgressMessage(String message) {
        messageView.setVisibility(VISIBLE);
        messageView.setText(message);
    }

    @Override
    public void hideProgressMessage() {
        messageView.setVisibility(GONE);
        messageView.setText("");
    }

    @Override
    public boolean isProgressVisible() {
        return getVisibility() == VISIBLE;
    }

    private void init() {
        setLayoutParams(new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setClickable(true);
        setBackgroundColor(ContextCompat.getColor(getContext(), R.color.progressBackground));
        inflate(getContext(), R.layout.layout_progress_modern, this);

        messageView = (TextView) findViewById(R.id.textView);
        hideProgress();
    }
}
