package com.istatkevich.cmvp.core.progressoverlay;

/**
 * Created by i.statkevich on 13.03.2017.
 */

public interface Progress {
    void showProgress();

    void showProgress(String message);

    void hideProgress();

    void setProgressMessage(String message);

    void hideProgressMessage();

    boolean isProgressVisible();
}
