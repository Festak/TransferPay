package com.istatkevich.cmvp.core.fragmentswitcher;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by i.statkevich on 5/17/17.
 */

public class FragmentParams implements Parcelable {
    private int id;
    private Bundle arguments;

    public FragmentParams(int id, Bundle arguments) {
        this.id = id;
        this.arguments = arguments;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Bundle getArguments() {
        return arguments;
    }

    public void setArguments(Bundle arguments) {
        this.arguments = arguments;
    }

    public static final Creator<FragmentParams> CREATOR = new Creator<FragmentParams>() {
        @Override
        public FragmentParams createFromParcel(Parcel in) {
            return new FragmentParams(in);
        }

        @Override
        public FragmentParams[] newArray(int size) {
            return new FragmentParams[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(id);
        dest.writeBundle(arguments);
    }

    protected FragmentParams(Parcel in) {
        id = in.readInt();
        arguments = in.readBundle();
    }
}
