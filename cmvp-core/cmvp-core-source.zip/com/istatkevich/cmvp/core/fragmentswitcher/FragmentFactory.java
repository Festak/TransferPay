package com.istatkevich.cmvp.core.fragmentswitcher;

import android.support.v4.app.Fragment;

/**
 * Created by i.statkevich on 5/4/17.
 */

public interface FragmentFactory {
    Class<? extends Fragment> getFragmentClass(int fragmentId);
}
