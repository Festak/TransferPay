package com.istatkevich.cmvp.core.fragmentswitcher;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;

import com.istatkevich.cmvp.core.viewmodel.ViewModel;


/**
 * Created by i.statkevich on 08.10.2015.
 */
public class FragmentSwitcher {
    public static final int UNDEFINED_FRAGMENT = 0;

    private FragmentManager fragmentManager;
    private FragmentFactory fragmentFactory;

    private ViewModel viewModel;
    private FragmentParams fragmentParams;

    private String fieldFragmentParams;

    private int containerId;

    public FragmentSwitcher(FragmentManager fragmentManager, FragmentFactory fragmentFactory, int containerId, ViewModel viewModel) {
        this.fragmentManager = fragmentManager;
        this.fragmentFactory = fragmentFactory;

        this.containerId = containerId;
        this.viewModel = viewModel;

        this.fieldFragmentParams = generateViewDataFieldName("fragmentParams");
    }

    /**
     * Restores fragment params from viewModel
     *
     * @return if data was restored return true
     */
    public boolean restoreFragment() {
        fragmentParams = viewModel.getExtraParcelable(fieldFragmentParams);

        if (fragmentParams.getId() == UNDEFINED_FRAGMENT) {
            return false;
        }

        switchTo(fragmentParams);
        return true;
    }

    public void switchTo(int fragmentId) {
        switchTo(fragmentId, null);
    }

    public void switchTo(int fragmentId, Bundle fragmentArguments) {
        switchTo(new FragmentParams(fragmentId, fragmentArguments));
    }

    public void switchTo(FragmentParams fragmentParams) {
        Class<? extends Fragment> fragmentClass;

        fragmentClass = fragmentFactory.getFragmentClass(fragmentParams.getId());

        if (fragmentClass == null) {
            return;
        }

        try {
            String fragmentTag = fragmentClass.getSimpleName();

            if (isFragmentExist(fragmentClass.getSimpleName())) {
                // Fragment already existed, exit
                return;
            }

            Fragment fragment = fragmentClass.newInstance();

            if (fragmentParams.getArguments() != null) {
                fragment.setArguments(fragmentParams.getArguments());
            }

            fragmentManager.beginTransaction()
                    .replace(containerId, fragment, fragmentTag)
                    .commitAllowingStateLoss();

            this.fragmentParams = fragmentParams;
            viewModel.putExtraParcelable(fieldFragmentParams, fragmentParams);
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    public FragmentParams getFragmentParams() {
        return fragmentParams;
    }

    public FragmentFactory getFragmentFactory() {
        return fragmentFactory;
    }

    private boolean isFragmentExist(String fragmentTag) {
        return fragmentManager.findFragmentByTag(fragmentTag) != null;
    }

    private String generateViewDataFieldName(String suffix) {
        return "cmvp_fragment_switcher_" + getClass().getName() + " _fragment_" + suffix;
    }
}
