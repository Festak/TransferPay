package com.istatkevich.cmvp.core.dialog;

/**
 * Created by i.statkevich on 13.10.2015.
 */
public interface DialogListener {
    void onDialogClickButton(int dialogId, int which);
    void onDialogBackPressed(int dialogId);
}
