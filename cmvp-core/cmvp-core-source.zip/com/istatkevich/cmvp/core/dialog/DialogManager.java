package com.istatkevich.cmvp.core.dialog;

import android.support.annotation.CallSuper;
import android.util.Log;

import com.istatkevich.cmvp.core.container.ActivityContainer;
import com.istatkevich.cmvp.core.constants.Fields;
import com.istatkevich.cmvp.core.constants.Settings;
import com.istatkevich.cmvp.core.viewmodel.ViewModel;

/**
 * Created by i.statkevich on 17.05.2016.
 */
public class DialogManager {
    public static final int DIALOG_ALERT = 1000010;
    public static final int DIALOG_CONFIRM = 1000020;
    public static final int UNDEFINED_DIALOG = 0;

    private BaseDialog<ViewModel> dialog;
    private DialogListener dialogListener;
    private ViewModel viewModel;

    private ActivityContainer activityContainer;
    private DialogFactory dialogFactory;

    private String fieldNameDialogType;
    private String fieldNameDialogId;

    public DialogManager(ActivityContainer activityContainer, ViewModel viewModel, DialogListener dialogListener) {
        this(activityContainer, null, viewModel, dialogListener);
    }

    public DialogManager(ActivityContainer activityContainer, DialogFactory dialogFactory, ViewModel viewModel, DialogListener dialogListener) {
        fieldNameDialogType = generateFieldNameForExternalStorage("dialogType");
        this.fieldNameDialogId = generateFieldNameForExternalStorage("dialogId");

        this.activityContainer = activityContainer;
        this.dialogFactory = dialogFactory;
        this.viewModel = viewModel;
        this.dialogListener = dialogListener;

        int dialogType = viewModel.getExtraInteger(fieldNameDialogType);
        int dialogId = viewModel.getExtraInteger(fieldNameDialogId);
        boolean isActivityRecreated = activityContainer.isRecreated();

        if (isActivityRecreated && dialogId != UNDEFINED_DIALOG) {
            openDialog(dialogType, dialogId);
        }
    }

    @CallSuper
    public void onDestroy() {
        if (dialog != null) {
            unlinkDialog();
        }
    }

    @CallSuper
    public void openDialog(int dialogType, int dialogId) {
        if (activityContainer.isProgressVisible()) {
            activityContainer.hideProgress();
        }

        dialog = createDialog(dialogType);

        if (dialog == null) {
            Log.w(Settings.LOG_TAG, "Dialog id " + dialogId + " does not support");
        }

        viewModel.putExtraInteger(fieldNameDialogType, dialogType);
        viewModel.putExtraInteger(fieldNameDialogId, dialogId);

        dialog.showDialog(viewModel, dialogId, new DialogListener() {
            @Override
            public void onDialogClickButton(int dialogId, int which) {
                closeDialog();
                dialogListener.onDialogClickButton(dialogId, which);
            }

            @Override
            public void onDialogBackPressed(int dialogId) {
                closeDialog();
                dialogListener.onDialogBackPressed(dialogId);
            }
        });
    }

    public void openAlertDialog(int dialogId, String title, String message, String buttonText) {
        viewModel.putExtraString(Fields.DIALOG_SIMPLE_TITLE, title);
        viewModel.putExtraString(Fields.DIALOG_SIMPLE_MESSAGE, message);
        viewModel.putExtraString(Fields.DIALOG_POSITIVE_BUTTON_TEXT, buttonText);

        openDialog(DIALOG_ALERT, dialogId);
    }

    public void openConfirmDialog(int dialogId, String title, String message, String positiveButtonText, String negativeButtonText) {
        viewModel.putExtraString(Fields.DIALOG_SIMPLE_TITLE, title);
        viewModel.putExtraString(Fields.DIALOG_SIMPLE_MESSAGE, message);
        viewModel.putExtraString(Fields.DIALOG_POSITIVE_BUTTON_TEXT, positiveButtonText);
        viewModel.putExtraString(Fields.DIALOG_NEGATIVE_BUTTON_TEXT, negativeButtonText);

        openDialog(DIALOG_CONFIRM, dialogId);
    }

    private BaseDialog<ViewModel> createDialog(int dialogType) {
        switch (dialogType) {
            case DIALOG_ALERT:
                return new SimpleDialog<>(activityContainer, viewModel);
            case DIALOG_CONFIRM:
                return new ConfirmDialog<>(activityContainer, viewModel);
            default:
                return dialogFactory != null ? dialogFactory.createDialog(dialogType) : null;
        }
    }

    private void unlinkDialog() {
        if (dialog != null) {
            dialog.dismiss();
            dialog = null;
        }
    }

    private void closeDialog() {
        unlinkDialog();
        viewModel.putExtraInteger(fieldNameDialogId, UNDEFINED_DIALOG);
    }

    private String generateFieldNameForExternalStorage(String fieldName) {
        return this.getClass().getSimpleName() + fieldName;
    }
}
