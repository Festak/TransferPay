package com.istatkevich.cmvp.core.dialog;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.view.LayoutInflater;

import com.istatkevich.cmvp.core.container.ActivityContainer;
import com.istatkevich.cmvp.core.constants.Fields;
import com.istatkevich.cmvp.core.viewmodel.ViewModel;


/**
 * Created by i.statkevich on 11.11.2015.
 */
public class SimpleDialog<VM extends ViewModel> extends BaseDialog<VM> {

    public SimpleDialog(ActivityContainer activityContainer, VM viewData) {
        super(activityContainer, viewData);
    }

    @Override
    public android.app.AlertDialog.Builder createDialog(LayoutInflater inflater) {
        AlertDialog.Builder builder = new android.app.AlertDialog.Builder(getContext());

        String title = getViewData().getExtraString(Fields.DIALOG_SIMPLE_TITLE);
        String message = getViewData().getExtraString(Fields.DIALOG_SIMPLE_MESSAGE);
        String positiveButton = getViewData().getExtraString(Fields.DIALOG_POSITIVE_BUTTON_TEXT);

        builder.setTitle(title);
        builder.setMessage(message);
        builder.setPositiveButton(positiveButton, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialogClickButton(Dialog.BUTTON_POSITIVE);
            }
        });

        return builder;
    }
}
