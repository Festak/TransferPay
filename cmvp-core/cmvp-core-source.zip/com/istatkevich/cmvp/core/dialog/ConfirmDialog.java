package com.istatkevich.cmvp.core.dialog;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.view.LayoutInflater;

import com.istatkevich.cmvp.core.container.ActivityContainer;
import com.istatkevich.cmvp.core.constants.Fields;
import com.istatkevich.cmvp.core.viewmodel.ViewModel;

public class ConfirmDialog<VM extends ViewModel> extends BaseDialog<VM> {
    public ConfirmDialog(ActivityContainer activityContainer, VM viewData) {
        super(activityContainer, viewData);
    }

    @Override
    public AlertDialog.Builder createDialog(LayoutInflater inflater) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());

        String title = getViewData().getExtraString(Fields.DIALOG_SIMPLE_TITLE);
        String message = getViewData().getExtraString(Fields.DIALOG_SIMPLE_MESSAGE);
        String positiveButton = getViewData().getExtraString(Fields.DIALOG_POSITIVE_BUTTON_TEXT);
        String negativeButton = getViewData().getExtraString(Fields.DIALOG_NEGATIVE_BUTTON_TEXT);

        builder.setTitle(title);
        builder.setMessage(message);
        builder.setPositiveButton(positiveButton, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialogClickButton(Dialog.BUTTON_POSITIVE);
            }
        });
        builder.setNegativeButton(negativeButton, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialogClickButton(Dialog.BUTTON_NEGATIVE);
            }
        });

        return builder;
    }
}
