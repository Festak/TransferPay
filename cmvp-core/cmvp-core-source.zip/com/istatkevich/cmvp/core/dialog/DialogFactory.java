package com.istatkevich.cmvp.core.dialog;

import com.istatkevich.cmvp.core.viewmodel.ViewModel;

/**
 * Created by i.statkevich on 5/4/17.
 */

public interface DialogFactory {
    BaseDialog<ViewModel> createDialog(int dialogId);
}
