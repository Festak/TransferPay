package com.istatkevich.cmvp.core.dialog;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.support.annotation.CallSuper;
import android.view.KeyEvent;
import android.view.LayoutInflater;

import com.istatkevich.cmvp.core.container.ActivityContainer;
import com.istatkevich.cmvp.core.viewmodel.ViewModel;


/**
 * Created by i.statkevich on 13.10.2015.
 */
public abstract class BaseDialog<VM extends ViewModel> {
    private Context context;
    private DialogListener dialogListener;
    private VM viewData;
    private int dialogId;

    private AlertDialog alertDialog;

    public BaseDialog(ActivityContainer context, VM viewData) {
        this.context = context;
        this.viewData = viewData;
    }

    public abstract AlertDialog.Builder createDialog(LayoutInflater inflater);

    /**
     * Shows AlertDialog
     * This is example how to change dialog width and height alertDialog.getWindow().setLayout(200, 200);
     *
     * @param viewData       viewModel
     * @param dialogId       dialogId
     * @param dialogListener dialogListener
     * @return AlertDialog
     */
    public AlertDialog showDialog(VM viewData, int dialogId, DialogListener dialogListener) {
        this.viewData = viewData;
        this.dialogId = dialogId;
        this.dialogListener = dialogListener;

        LayoutInflater layoutInflater = LayoutInflater.from(context);

        AlertDialog.Builder builder = createDialog(layoutInflater);

        builder.setOnKeyListener(new DialogInterface.OnKeyListener() {
            @Override
            public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_UP) {
                    BaseDialog.this.dialogListener.onDialogBackPressed(BaseDialog.this.dialogId);
                }

                return false;
            }
        });

        alertDialog = builder.create();
        alertDialog.setCanceledOnTouchOutside(false);
        alertDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialog) {
                clearData();
            }
        });

        alertDialog.show();

        return alertDialog;
    }

    @CallSuper
    public void clearData() {
        context = null;
        dialogListener = null;
        viewData = null;
    }

    @CallSuper
    public void dismiss() {
        if (alertDialog != null && alertDialog.isShowing()) {
            alertDialog.dismiss();
        }
    }

    public Context getContext() {
        return context;
    }

    public VM getViewData() {
        return viewData;
    }

    public int getDialogId() {
        return dialogId;
    }

    @CallSuper
    protected void dialogClickButton(int which) {
        dialogListener.onDialogClickButton(dialogId, which);
    }
}
