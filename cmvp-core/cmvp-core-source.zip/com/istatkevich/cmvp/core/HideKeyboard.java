package com.istatkevich.cmvp.core;

/**
 * Created by i.statkevich on 5/16/17.
 */

public interface HideKeyboard {
    void hideKeyboard();
}
