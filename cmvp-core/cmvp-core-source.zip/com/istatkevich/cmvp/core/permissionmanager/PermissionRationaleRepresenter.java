package com.istatkevich.cmvp.core.permissionmanager;

/**
 * Created by i.statkevich on 06.01.2017.
 */

public interface PermissionRationaleRepresenter {
    void onShowPermissionRationale(String[] permissionsDenied, String[] permissionsDontAskAgain);
}
