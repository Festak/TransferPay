package com.istatkevich.cmvp.core.permissionmanager;

/**
 * Created by i.statkevich on 06.12.2016.
 */

public interface PermissionObserver {

    void checkPermission();

    /**
     * If user granted all permission, calls this callback.
     */
    void onPermissionGranted();

    /**
     * If user denied some permissions, calls this callback. Required permission divided on permissionsAllowed, permissionsDenied and permissionsDontAskAgain.
     *
     * @param permissionsAllowed allowed permissions
     * @param permissionsDenied user denied this permission, contains permissionsDontAskAgain too
     * @param permissionsDontAskAgain user denied and chosen "Don't ask again" for this permission. Android con't requests this permission, user can allows or resets this permission via application settings.
     */
    void onPermissionDenied(String[] permissionsAllowed, String[] permissionsDenied, String[] permissionsDontAskAgain);

    /**
     * Returns list of required permissions
     */
    String[] getRequiredPermissions();
}
