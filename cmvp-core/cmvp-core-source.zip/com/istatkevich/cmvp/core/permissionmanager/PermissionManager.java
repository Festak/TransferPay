package com.istatkevich.cmvp.core.permissionmanager;

import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * Checks required permissions, requests not allowed permissions, parses onProcessRequestResult, delivers a result via PermissionObserver
 * CheckPermission when on activity resume and when registered new permission observer
 * <p>
 * Created by i.statkevich on 06.12.2016.
 */

public class PermissionManager {
    private Activity activity;
    private PermissionRationaleRepresenter permissionRationaleRepresenter;
    private Map<String, PermissionObserver> registeredPermissionObservers;
    private Map<String, PermissionObserver> inProcessPermissionObservers;
    private int requestCode;

    private Set<String> registeredPermissionsRequired;
    private Set<String> inProcessPermissionsRequired;
    private Set<String> permissionsAllowed;
    // TODO must be stayed permissionsDenied instant permissionsNotAllowed
    /**
     * permissionsNotAllowed - permissionsDenied equal to permissionsNotAllowed and consists NotAllowed and DontAskAgain permissions
     */
    private Set<String> permissionsNotAllowed;
    private Set<String> permissionsDontAskAgain;
    private Set<String> permissionsDenied;

    private boolean isRationaleDisplay;
    private boolean hasNewPermissionObservers;
    private boolean isActivityReady;

    public PermissionManager(Activity activity, int requestCode, PermissionRationaleRepresenter permissionRationaleRepresenter) {
        this.activity = activity;
        this.requestCode = requestCode;
        this.permissionRationaleRepresenter = permissionRationaleRepresenter;

        resetData();
    }

    public void registerPermissionObserver(@NonNull String observerId, @NonNull PermissionObserver permissionObserver) {
        registeredPermissionObservers.put(
                observerId,
                permissionObserver
        );

        String[] permissions = permissionObserver.getRequiredPermissions();

        if (permissions == null || permissions.length == 0) {
            permissionObserver.onPermissionGranted();
            return;
        }

        hasNewPermissionObservers = true;
        registeredPermissionsRequired.addAll(Arrays.asList(permissions));

        if (isActivityReady) {
            /*
             Presenter implements PermissionObserver,
             Presenter can be registered as PermissionObserver before and after that Android will invoke onResume of activity
             Skips checkPermissions if isActivityReady = false because activity is not ready and it calls the checkPermissions in onActivityStart
             */
            checkPermissions();
        }
    }

    public void unregisterPermissionObserver(String observerId) {
        registeredPermissionObservers.remove(observerId);
        inProcessPermissionObservers.remove(observerId);
    }

    public void onActivityStart() {
        isActivityReady = true;
        checkPermissions();
    }

    public void onRationaleCompleted() {
        isRationaleDisplay = false;
        requestPermissions();
    }

    public void onProcessRequestResult(int requestCode, String[] permissions, int[] grantResults) {
        // If request is cancelled, the result arrays are empty.
        if (this.requestCode != requestCode || grantResults.length == 0) {
            deliverResult();
            return;
        }

        updateAndDeliverResult(permissions, grantResults);
    }

    public void release() {
        resetData();
    }

    private void checkPermissions() {
        if (isRationaleDisplay) {
            return;
        }

        prepareDataToCheckAndRequestPermission();
        hasNewPermissionObservers = false;

        if (Build.VERSION.SDK_INT < 23 || !hasRequiredPermission()) {
            deliverAllPermission();
        } else {
            defineAllowedAndNotAllowedPermission();

            if (permissionsNotAllowed.size() > 0) {
                defineDeniedAndDontAskAgainPermissions();

                if (permissionsDenied.size() > 0) {
                    showPermissionRationale();
                } else {
                    deliverResult();
                }
            } else {
                deliverAllPermission();
            }
        }
    }

    /**
     * Activity implements onShowPermissionRationale and displays dialog
     * PermissionManager waiting at that time still user read a rationale
     * When user clicks "Ok" in the dialog, Activity calls permissionManager.onRationaleCompleted()
     * and PermissionManager continue works
     */
    private void showPermissionRationale() {
        isRationaleDisplay = true;
        permissionRationaleRepresenter.onShowPermissionRationale(
                setToArrayString(permissionsDenied),
                setToArrayString(permissionsDontAskAgain)
        );
    }

    private void requestPermissions() {
        if (permissionsDenied != null && permissionsDenied.size() > 0) {
            ActivityCompat.requestPermissions(activity, setToArrayString(permissionsDenied), requestCode);
        }
    }

    private void defineAllowedAndNotAllowedPermission() {
        permissionsAllowed = new HashSet<>();
        permissionsNotAllowed = new HashSet<>();

        for (String permission : inProcessPermissionsRequired) {
            if (isPermissionGranted(permission)) {
                permissionsAllowed.add(permission);
            } else {
                permissionsNotAllowed.add(permission);
            }
        }
    }

    private void defineDeniedAndDontAskAgainPermissions() {
        permissionsDenied = new HashSet<>();
        permissionsDontAskAgain = new HashSet<>();

        for (String permission : permissionsNotAllowed) {
            permissionsDenied.add(permission);

            if (!ActivityCompat.shouldShowRequestPermissionRationale(activity, permission)) {
                // User didn't allow this permission and Android don't recommends show a rationale to allow permission
                // that means user chosen Don't ask again and denied the permission
                permissionsDontAskAgain.add(permission);
            }
        }
    }

    private boolean isPermissionGranted(String permission) {
        return ContextCompat.checkSelfPermission(activity, permission) == PackageManager.PERMISSION_GRANTED;
    }

    private void updateAndDeliverResult(String[] permissions, int[] grantResults) {
        for (int i = 0; i < grantResults.length; i++) {
            String permission = permissions[i];

            // Chooses allowed permissions
            if (grantResults[i] == PackageManager.PERMISSION_GRANTED) {
                permissionsAllowed.add(permission);
                permissionsDenied.remove(permission);
                permissionsDontAskAgain.remove(permission);
            } else if (!ActivityCompat.shouldShowRequestPermissionRationale(activity, permission)) {
                // User didn't allow this permission and Android don't recommends show a rationale to allow permission
                // that means user chosen Don't ask again and denied the permission
                permissionsDontAskAgain.add(permission);
                permissionsDenied.remove(permission);
            } else {
                // do nothing with permission, it is in permissionsDenied
            }
        }

        deliverResult();
    }

    private void deliverAllPermission() {
        permissionsAllowed = new HashSet<>(inProcessPermissionsRequired);
        deliverResult();
    }

    private void deliverResult() {
        for (Map.Entry<String, PermissionObserver> entry : inProcessPermissionObservers.entrySet()) {
            deliverResultToPermissionObserver(entry.getValue());
        }

        if(hasNewPermissionObservers && isActivityReady) {
            checkPermissions();
        }
    }

    private void deliverResultToPermissionObserver(PermissionObserver permissionObserver) {
        String[] observerRequiredPermissions = permissionObserver.getRequiredPermissions();

        if (observerRequiredPermissions == null || observerRequiredPermissions.length == 0 || permissionsDenied.size() == 0) {
            permissionObserver.onPermissionGranted();
        } else {
            String[] allowed = intersectionPermissions(observerRequiredPermissions, setToArrayString(permissionsAllowed));
            String[] denied = excludePermissions(observerRequiredPermissions, allowed);
            String[] dontAskAgain = intersectionPermissions(denied, setToArrayString(permissionsDontAskAgain));

            if (denied.length == 0) {
                permissionObserver.onPermissionGranted();
            } else {
                permissionObserver.onPermissionDenied(allowed, denied, dontAskAgain);
            }
        }
    }

    private String[] intersectionPermissions(String[] permissionsA, String[] permissionsB) {
        Set<String> result = new HashSet<>(Arrays.asList(permissionsA));
        result.retainAll(new HashSet<>(Arrays.asList(permissionsB)));

        return setToArrayString(result);
    }

    private String[] excludePermissions(String[] permissionsA, String[] permissionsB) {
        Set<String> result = new HashSet<>(Arrays.asList(permissionsA));
        result.removeAll(new HashSet<>(Arrays.asList(permissionsB)));

        return setToArrayString(result);
    }

    private String[] setToArrayString(Set<String> set) {
        return set.toArray(new String[set.size()]);
    }

    private boolean hasRequiredPermission() {
        return inProcessPermissionsRequired != null && inProcessPermissionsRequired.size() > 0;
    }

    private void prepareDataToCheckAndRequestPermission() {
        permissionsAllowed = new HashSet<>();
        permissionsNotAllowed = new HashSet<>();
        permissionsDontAskAgain = new HashSet<>();
        permissionsDenied = new HashSet<>();

        inProcessPermissionObservers = new HashMap<>(registeredPermissionObservers);
        inProcessPermissionsRequired = new HashSet<>(registeredPermissionsRequired);
    }

    private void resetData() {
        registeredPermissionsRequired = new HashSet<>();
        inProcessPermissionsRequired = new HashSet<>();

        registeredPermissionObservers = new HashMap<>();
        inProcessPermissionObservers = new HashMap<>();
    }
}
