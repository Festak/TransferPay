package com.istatkevich.cmvp.core.router;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import com.istatkevich.cmvp.core.constants.Fields;

/**
 * Created by i.statkevich on 03.03.2016.
 */
public class Router {
    private Context context;

    public Router(Context context) {
        this.context = context;
    }

    public Context getContext() {
        return context;
    }

    public void openActivity(ActivityDestinationParams destinationParams) {
        openActivity(
                destinationParams.getClazz(),
                destinationParams.getArguments(),
                destinationParams.getCurrentActivityCode(),
                destinationParams.isShouldFinish(),
                destinationParams.isShouldClearTask(),
                destinationParams.getRequestCode()
        );
    }

    public void openActivity(Class activityClass, Bundle args) {
        openActivity(activityClass, args, 0, false, false, 0);
    }

    public void openActivity(Class activityClass, Bundle arguments, int currentActivityCode, boolean shouldFinish, boolean shouldClearTask, int requestCode) {
        Intent intent = new Intent(context, activityClass);
        openActivity(intent, arguments, currentActivityCode, shouldFinish, shouldClearTask, requestCode);
    }

    public void openActivity(Intent intent, Bundle arguments, int currentActivityCode, boolean shouldFinish, boolean shouldClearTask, int requestCode) {
        if (arguments != null) {
            intent.putExtras(arguments);
        }

        if (shouldClearTask) {
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        }

        intent.putExtra(Fields.FIELD_PARENT_ACTIVITY_CODE, currentActivityCode);

        if(context instanceof Activity) {
            Activity activity = (Activity) context;
            activity.startActivityForResult(intent, requestCode);

            if (shouldFinish) {
                activity.finish();
            }
        } else {
            context.startActivity(intent);
        }
    }
}
