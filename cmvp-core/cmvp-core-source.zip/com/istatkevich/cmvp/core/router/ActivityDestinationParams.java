package com.istatkevich.cmvp.core.router;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by i.statkevich on 6/1/17.
 */

public class ActivityDestinationParams {
    private Class<? extends AppCompatActivity> clazz;
    private Bundle arguments;
    private int currentActivityCode;
    private boolean shouldFinish;
    private boolean shouldClearTask;
    private int requestCode;

    public ActivityDestinationParams(Class<? extends AppCompatActivity> clazz, Bundle arguments) {
        this.clazz = clazz;
        this.arguments = arguments;
    }

    public ActivityDestinationParams(Class<? extends AppCompatActivity> clazz, Bundle arguments, int currentActivityCode, boolean shouldFinish, boolean shouldClearTask, int requestCode) {
        this.clazz = clazz;
        this.arguments = arguments;
        this.currentActivityCode = currentActivityCode;
        this.shouldFinish = shouldFinish;
        this.shouldClearTask = shouldClearTask;
        this.requestCode = requestCode;
    }

    public Class<? extends AppCompatActivity> getClazz() {
        return clazz;
    }

    public Bundle getArguments() {
        return arguments;
    }

    public int getCurrentActivityCode() {
        return currentActivityCode;
    }

    public boolean isShouldFinish() {
        return shouldFinish;
    }

    public boolean isShouldClearTask() {
        return shouldClearTask;
    }

    public int getRequestCode() {
        return requestCode;
    }
}
