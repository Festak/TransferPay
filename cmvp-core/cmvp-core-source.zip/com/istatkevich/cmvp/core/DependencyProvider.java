package com.istatkevich.cmvp.core;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by i.statkevich on 18.01.2017.
 */

public class DependencyProvider {
    private static DependencyProvider instance;

    private Map<String, Object> globalScope;
    private Map<String, Object> activityScope;

    private DependencyProvider() {
        init();
    }

    public static DependencyProvider getInstance() {
        if(instance == null) {
            instance = new DependencyProvider();
        }

        return instance;
    }

    public void add(String key, Object dependency) {
        globalScope.put(key, dependency);
    }

    public <T> T get(String key, Class<T> clazz) {
        return (T) globalScope.get(key);
    }

    public void addActivityScope(String key, Object dependency) {
        activityScope.put(key, dependency);
    }

    public <T> T getActivityScope(String key, Class<T> clazz) {
        return (T) activityScope.get(key);
    }

    public void releaseActivityScope() {
        activityScope.clear();
    }

    private void init() {
        globalScope = new HashMap<>();
        activityScope = new HashMap<>();
    }
}
