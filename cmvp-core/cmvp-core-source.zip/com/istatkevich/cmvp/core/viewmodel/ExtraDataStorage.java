package com.istatkevich.cmvp.core.viewmodel;

import android.os.Bundle;
import android.os.Parcelable;

/**
 * Created by i.statkevich on 23.11.2015.
 */
public interface ExtraDataStorage {
    String getExtraString(String key);

    Bundle getExtraBundle(String key);

    <T extends Parcelable> T getExtraParcelable(String key);

    int getExtraInteger(String key);

    double getExtraDouble(String key);

    boolean getExtraBoolean(String key);

    void putExtraString(String key, String value);

    void putExtraBundle(String key, Bundle value);

    void putExtraParcelable(String key, Parcelable value);

    void putExtraInteger(String key, int value);

    void putExtraDouble(String key, double value);

    void putExtraBoolean(String key, boolean value);
}
