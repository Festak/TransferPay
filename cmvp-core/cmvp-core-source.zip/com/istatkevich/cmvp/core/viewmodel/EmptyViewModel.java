package com.istatkevich.cmvp.core.viewmodel;

/**
 * Empty Cmvp viewModel
 */
public class EmptyViewModel extends ViewModel {
}
