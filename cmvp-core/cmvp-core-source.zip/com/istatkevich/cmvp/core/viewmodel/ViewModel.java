package com.istatkevich.cmvp.core.viewmodel;

import android.os.Bundle;
import android.os.Parcelable;
import android.support.annotation.CallSuper;

/**
 * Created by i.statkevich on 28.07.2015.
 */
public abstract class ViewModel implements ExtraDataStorage {
    private static final String BUNDLE_VIEW_DATA = "bundle_inner_data";
    private static final String BUNDLE_EXTRA_DATA = "bundle_extra_data";

    private String viewDataName;
    private Bundle extraData;
    private Bundle data;

    @CallSuper
    public void onCreate(Bundle savedInstanceState) {
        this.viewDataName = this.getClass().getSimpleName();

        onPrepareCreate();

        if(savedInstanceState != null) {
            restoreState(savedInstanceState);
        } else {
            initState();
        }
    }

    public void onSaveInstanceState(Bundle outState) {
        onPrepareSave();

        if(!data.isEmpty()) {
            putBundleToOutState(BUNDLE_VIEW_DATA, data, outState);
        }

        if(!extraData.isEmpty()) {
            putBundleToOutState(BUNDLE_EXTRA_DATA, extraData, outState);
        }
    }

    @Override
    public String getExtraString(String key) {
        return extraData.getString(key);
    }

    @Override
    public Bundle getExtraBundle(String key) {
        return extraData.getBundle(key);
    }

    @Override
    public <T extends Parcelable> T getExtraParcelable(String key) {
        return extraData.getParcelable(key);
    }

    @Override
    public int getExtraInteger(String key) {
        return extraData.getInt(key);
    }

    @Override
    public double getExtraDouble(String key) {
        return extraData.getDouble(key);
    }

    @Override
    public boolean getExtraBoolean(String key) {
        return extraData.getBoolean(key);
    }

    @Override
    public void putExtraString(String key, String value) {
        extraData.putString(key, value);
    }

    @Override
    public void putExtraBundle(String key, Bundle value) {
        extraData.putBundle(key, value);
    }

    @Override
    public void putExtraParcelable(String key, Parcelable value) {
        extraData.putParcelable(key, value);
    }

    @Override
    public void putExtraInteger(String key, int value) {
        extraData.putInt(key, value);
    }

    @Override
    public void putExtraDouble(String key, double value) {
        extraData.putDouble(key, value);
    }

    @Override
    public void putExtraBoolean(String key, boolean value) {
        extraData.putBoolean(key, value);
    }

    protected void onPrepareCreate() {
        // do nothing
    }

    protected void onPrepareSave() {
        // do nothing
    }

    protected void onRestored() {
        // do nothing
    }

    protected void onInitDefaultData() {
        //do nothing
    }

    protected Bundle getData() {
        return data;
    }

    private void initState() {
        extraData = new Bundle();
        data = new Bundle();

        onInitDefaultData();
    }

    private void restoreState(Bundle savedInstanceState) {
        data = restoreBundle(BUNDLE_VIEW_DATA, savedInstanceState);
        extraData = restoreBundle(BUNDLE_EXTRA_DATA, savedInstanceState);

        onRestored();
    }

    private Bundle restoreBundle(String key, Bundle savedInstanceState) {
        String bundleName = defineBundleName(key);
        Bundle result = savedInstanceState != null ? savedInstanceState.getBundle(bundleName) : null;

        if(result == null) {
            result = new Bundle();
        }

        return result;
    }

    private void putBundleToOutState(String key, Bundle data, Bundle outState) {
        String bundleName = defineBundleName(key);

        outState.putBundle(bundleName, data);
    }

    private String defineBundleName(String key) {
        return viewDataName + "_" +  key;
    }
}
