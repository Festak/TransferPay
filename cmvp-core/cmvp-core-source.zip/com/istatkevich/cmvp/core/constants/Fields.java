package com.istatkevich.cmvp.core.constants;

/**
 * Contains a names fields
 * Use Constants.class for other constants
 */
public class Fields {

    private Fields() {
        //nothing
    }

    //Basic fields
    public static final String FIELD_PARENT_ACTIVITY_CODE = "field_parent_activity_code";

    //Dialog fields
    public static final String DIALOG_SIMPLE_TITLE = "validation_dialog_title";
    public static final String DIALOG_SIMPLE_MESSAGE = "validation_dialog_message";
    public static final String DIALOG_POSITIVE_BUTTON_TEXT = "dialog_positive_button_text";
    public static final String DIALOG_NEGATIVE_BUTTON_TEXT = "dialog_negative_button_text";



}
