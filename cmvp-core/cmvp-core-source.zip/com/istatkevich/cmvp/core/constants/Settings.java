package com.istatkevich.cmvp.core.constants;

/**
 * Contains the constants are not the names of the fields
 * Use Fields.class for names fields
 */
public class Settings {
    private Settings() {
        //nothing
    }

    //Log tags
    public static final String LOG_TAG = "cmvp_core";
}
