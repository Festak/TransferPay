package com.istatkevich.cmvp.core;

import android.content.Intent;

/**
 * Created by i.statkevich on 04.03.2016.
 */
public interface ActivityLifecycleListener {
    void onActivityResult(int requestCode, int resultCode, Intent data);

    void onActivityStart();

    void onActivityResume();

    void onActivityPause();

    void onActivityStop();
}
