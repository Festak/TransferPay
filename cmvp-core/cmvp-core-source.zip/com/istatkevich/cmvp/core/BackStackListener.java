package com.istatkevich.cmvp.core;

/**
 * Created by i.statkevich on 11.03.2016.
 */
public interface BackStackListener {
    boolean onUserBackPressed();
}
