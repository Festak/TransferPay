package com.istatkevich.cmvp.core;

import java.util.LinkedList;

/**
 * Created by i.statkevich on 11.03.2016.
 */
public class BackStackManager {
    private LinkedList<BackStackListener> backStack;

    public BackStackManager() {
        this.backStack = new LinkedList<>();
    }

    /**
     * Adds element to custom back stack
     *
     * @param backStackListener implemented interface CloseExecutor
     */
    public void add(BackStackListener backStackListener) {
        if (backStack.isEmpty() || !backStack.getLast().equals(backStackListener)) {
            backStack.add(backStackListener);
        }
    }

    public void remove(BackStackListener backStackListener) {
        backStack.remove(backStackListener);
    }

    /**
     * If last element return true remove it from back stack
     *
     * @return false if back stack is empty
     */
    public boolean userBackPressed() {
        if (backStack.isEmpty()) {
            return false;
        }

        BackStackListener listener = backStack.getLast();

        if(listener.onUserBackPressed()) {
            backStack.removeLast();
            return true;
        } else {
            return false;
        }
    }
}
