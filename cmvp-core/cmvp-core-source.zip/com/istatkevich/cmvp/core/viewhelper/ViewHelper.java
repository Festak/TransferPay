package com.istatkevich.cmvp.core.viewhelper;

import android.content.Context;
import android.databinding.DataBindingUtil;
import android.databinding.ViewDataBinding;
import android.support.annotation.CallSuper;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Toast;

import com.istatkevich.cmvp.core.container.ActivityContainer;
import com.istatkevich.cmvp.core.presenter.Presenter;
import com.istatkevich.cmvp.core.progressoverlay.Progress;


/**
 * Created by i.statkevich on 02.11.2015.
 */
public abstract class ViewHelper<P extends Presenter, B extends ViewDataBinding> implements Progress {
    private ActivityContainer activityContainer;
    private P presenter;
    private B binding;

    private Progress activityProgress;

    /**
     * Inflate a layout. Important has only one dependency is Context, this provide to display layout in edit mode,
     * for example for preview in Android Studio
     *
     * @param context
     */
    public void inflate(Context context) {
        LayoutInflater inflater = LayoutInflater.from(context);
        int layoutId = getLayoutId();

        binding = DataBindingUtil.inflate(inflater, layoutId, null, false);
    }

    @CallSuper
    public void injectDependencies(ActivityContainer activityContainer, P presenter) {
        this.activityContainer = activityContainer;
        this.presenter = presenter;
        this.activityProgress = activityContainer;

        onBindVariables(binding);
        onInitView();
    }

    public void showToast(int stringId, int duration) {
        String text = getActivityContainer().getString(stringId);
        showToast(text, duration);
    }

    public void showToast(String text, int duration) {
        Toast.makeText(getActivityContainer(), text, duration).show();
    }

    public void showToast(String text) {
        showToast(text, Toast.LENGTH_SHORT);
    }

    public View findViewById(int id) {
        return binding.getRoot().findViewById(id);
    }

    public View getRoot() {
        return binding.getRoot();
    }

    public B getBinding() {
        return binding;
    }

    @Override
    public void showProgress() {
        showProgress(null);
    }

    @Override
    public void showProgress(String message) {
        activityProgress.showProgress(message);
    }

    @Override
    public void hideProgress() {
        activityProgress.hideProgress();
    }

    @Override
    public void setProgressMessage(String message) {
        activityProgress.setProgressMessage(message);
    }

    @Override
    public void hideProgressMessage() {
        activityProgress.hideProgressMessage();
    }

    @Override
    public boolean isProgressVisible() {
        return activityProgress.isProgressVisible();
    }

    protected abstract int getLayoutId();

    protected void onBindVariables(B binding) {
        // do nothing
    }

    protected void onInitView() {
        // do nothings
    }

    protected ActivityContainer getActivityContainer() {
        return activityContainer;
    }

    protected P getPresenter() {
        return presenter;
    }
}
