package com.istatkevich.cmvp.core;


import android.content.Intent;
import android.os.Bundle;

import com.istatkevich.cmvp.core.permissionmanager.PermissionObserver;
import com.istatkevich.cmvp.core.presenter.Presenter;

/**
 * Created by i.statkevich on 17.05.2016.
 */
public interface Screen {

    <T> T getPresenter(String containerId, Class<T> controllerClass);

    void registerPresenter(String containerId, Presenter presenter);

    void unregisterPresenter(String containerId);

    void registerPermissionObserver(String observerId, PermissionObserver permissionObserver);

    void unregisterPermissionObserver(String observerId);

    void registerLifecycleListener(ActivityLifecycleListener listener);

    void unregisterLifecycleListener(ActivityLifecycleListener listener);

    void addToBackStack(BackStackListener backStackListener);

    void removeFromBackStack(BackStackListener backStackListener);

    void setActionBarTitle(String title);

    <R> R getRouter(Class<R> routerClass);

    Intent getIntent();

    void closeScreen();

    void closeScreen(int resultCode, Intent data);

    boolean isRecreated();

    DependencyProvider getDependencyProvider();
}
