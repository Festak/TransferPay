package com.istatkevich.cmvp.core;

import android.content.Intent;

import java.util.ArrayList;

/**
 * Created by i.statkevich on 04.03.2016.
 */
public class ActivityLifecycleManager extends ArrayList<ActivityLifecycleListener> implements ActivityLifecycleListener {

    @Override
    public void onActivityStart() {
        for(ActivityLifecycleListener listener : this) {
            listener.onActivityStart();
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        for(ActivityLifecycleListener listener : this) {
            listener.onActivityResult(requestCode, resultCode, data);
        }
    }

    @Override
    public void onActivityResume() {
        for(ActivityLifecycleListener listener : this) {
            listener.onActivityResume();
        }
    }

    @Override
    public void onActivityPause() {
        for(ActivityLifecycleListener listener : this) {
            listener.onActivityPause();
        }
    }

    @Override
    public void onActivityStop() {
        for(ActivityLifecycleListener listener : this) {
            listener.onActivityStop();
        }
    }

    public void release() {
        clear();
    }
}
