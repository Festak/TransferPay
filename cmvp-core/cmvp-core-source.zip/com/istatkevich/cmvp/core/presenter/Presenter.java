package com.istatkevich.cmvp.core.presenter;

import android.content.Intent;
import android.support.annotation.CallSuper;

import com.istatkevich.cmvp.core.ActivityLifecycleListener;
import com.istatkevich.cmvp.core.Screen;
import com.istatkevich.cmvp.core.DependencyProvider;
import com.istatkevich.cmvp.core.container.Container;
import com.istatkevich.cmvp.core.dialog.DialogListener;
import com.istatkevich.cmvp.core.dialog.DialogManager;
import com.istatkevich.cmvp.core.permissionmanager.PermissionObserver;
import com.istatkevich.cmvp.core.viewmodel.ViewModel;
import com.istatkevich.cmvp.core.viewhelper.ViewHelper;


public abstract class Presenter<VM extends ViewModel, VH extends ViewHelper>
        implements DialogListener, PermissionObserver, ActivityLifecycleListener {

    private VM viewData;
    private VH viewHelper;

    private Container container;
    private Screen screen;

    private String containerId;
    private boolean isPresenterStarted;

    /**
     * When the viewHelper created and attached the container calls injectDependencies
     *
     * @param viewHelper view helper
     */
    @CallSuper
    public void injectDependencies(Container container, VM viewData, VH viewHelper) {
        this.container = container;
        this.viewData = viewData;
        this.viewHelper = viewHelper;

        this.screen = container.getScreen();
        this.containerId = container.getContainerId();
    }

    @Override
    public void checkPermission() {
        // TODO
    }

    @Override
    public void onPermissionDenied(String[] permissionsAllowed, String[] permissionsDenied, String[] permissionsDontAskAgain) {
        // do nothing
    }

    @Override
    public void onPermissionGranted() {
        if (isPresenterStarted) {
            return;
        }

        isPresenterStarted = true;
        onPresenterReady();
    }

    @CallSuper
    public void onDestroy() {
        screen.unregisterPresenter(containerId);
        screen.unregisterPermissionObserver(containerId);
        screen.unregisterLifecycleListener(this);
    }

    @Override
    public void onDialogClickButton(int dialogId, int which) {
        //Do nothing
    }

    @Override
    public void onDialogBackPressed(int dialogId) {
        //Do nothing
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        //Do nothing
    }

    @Override
    public void onActivityStart() {
        //Do nothing
    }

    @Override
    public void onActivityResume() {
        //Do nothing
    }

    @Override
    public void onActivityPause() {
        //Do nothing
    }

    @Override
    public void onActivityStop() {
        //Do nothing
    }

    public VH getViewHelper() {
        return viewHelper;
    }


    public VM getViewModel() {
        return viewData;
    }

    @Override
    public String[] getRequiredPermissions() {
        return new String[0];
    }

    public Container getContainer() {
        return container;
    }

    public DialogManager getDialogManager() {
        return container.getDialogManager();
    }

    public <R> R getRouter(Class<R> classRouter) {
        return getScreen().getRouter(classRouter);
    }

    /**
     * Calls when permission granted
     */
    protected void onPresenterReady() {
        // do nothing
    }

    protected Screen getScreen() {
        return screen;
    }

    protected DependencyProvider getDependencyProvider() {
        return getScreen().getDependencyProvider();
    }
}
