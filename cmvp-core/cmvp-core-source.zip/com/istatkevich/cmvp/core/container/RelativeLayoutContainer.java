package com.istatkevich.cmvp.core.container;

import android.annotation.TargetApi;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.annotation.CallSuper;
import android.util.AttributeSet;
import android.view.View;
import android.widget.RelativeLayout;

import com.istatkevich.cmvp.core.DependencyProvider;
import com.istatkevich.cmvp.core.Screen;
import com.istatkevich.cmvp.core.dialog.DialogManager;
import com.istatkevich.cmvp.core.presenter.Presenter;
import com.istatkevich.cmvp.core.viewhelper.ViewHelper;
import com.istatkevich.cmvp.core.viewmodel.ViewModel;


/**
 * Created by i.statkevich on 03.03.2016.
 */
public abstract class RelativeLayoutContainer<VM extends ViewModel, VH extends ViewHelper<P, ?>, P extends Presenter>
        extends RelativeLayout
        implements Container {

    private static final String BUNDLE_FIELD_INSTANCE_STATE_PARENT = "instance_state_parent";
    private static final String BUNDLE_FIELD_INSTANCE_STATE_LOCAL = "instance_state_local";

    private ContainerDelegate<VM, VH, P> containerDelegate;
    private ActivityContainer activityContainer;

    private Bundle savedInstanceState;

    public RelativeLayoutContainer(Context context) {
        this(context, null);
    }

    public RelativeLayoutContainer(Context context, AttributeSet attrs) {
        this(context, attrs, -1);
    }

    public RelativeLayoutContainer(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);

        init(attrs);
    }

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    public RelativeLayoutContainer(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);

        init(attrs);
    }

    @CallSuper
    protected void init(AttributeSet attrs) {
        if(isInEditMode()) {
            return;
        }

        if (!(getContext() instanceof ActivityContainer)) {
            throw new IllegalStateException("Activity should be inherited from ActivityContainer");
        }

        activityContainer = (ActivityContainer) getContext();
        containerDelegate = new BaseContainerDelegate<>(activityContainer);

        if (getId() == View.NO_ID) {
            //View should have id to executes full view lifecycle in particular call onSaveInstanceState
            throw new IllegalStateException("You have to set unique id for " + getClass().getSimpleName() + " in " + getActivityContainer().getClass().getSimpleName() + " activity");
        }

        initAttributes(attrs);
    }

    @Override
    protected void onFinishInflate() {
        super.onFinishInflate();

        containerDelegate.onViewHelperCreated(getContext(), createViewHelper());
        addView(containerDelegate.getViewHelper().getRoot());
    }

    @Override
    protected void onRestoreInstanceState(Parcelable state) {
        Bundle bundle = (Bundle) state;

        super.onRestoreInstanceState(bundle.getParcelable(BUNDLE_FIELD_INSTANCE_STATE_PARENT));
        savedInstanceState = bundle.getBundle(BUNDLE_FIELD_INSTANCE_STATE_LOCAL);
    }

    @Override
    protected Parcelable onSaveInstanceState() {
        Bundle bundle = new Bundle();
        Bundle viewDataOutState = new Bundle();

        containerDelegate.onSaveInstanceState(viewDataOutState);

        bundle.putParcelable(BUNDLE_FIELD_INSTANCE_STATE_PARENT, super.onSaveInstanceState());
        bundle.putBundle(BUNDLE_FIELD_INSTANCE_STATE_LOCAL, viewDataOutState);

        return bundle;
    }

    @SuppressWarnings("uncheked")
    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();

        if(isInEditMode()) {
            return;
        }

        containerDelegate.onViewModelCreated(createViewData(), savedInstanceState);
        //TODO refactoring, savedInstanceState = null should find more safe place
        savedInstanceState = null;

        containerDelegate.onPresenterCreated(createPresenter(), getContainerId());
        containerDelegate.onDialogManagerCreated(createDialogManager());
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();

        if(isInEditMode()) {
            return;
        }

        containerDelegate.onDestroy();
    }

    public VM getViewData() {
        return containerDelegate.getViewModel();
    }

    public VH getViewHelper() {
        return containerDelegate.getViewHelper();
    }

    public P getPresenter() {
        return containerDelegate.getPresenter();
    }

    public ActivityContainer getActivityContainer() {
        return activityContainer;
    }

    @Override
    public Screen getScreen() {
        return activityContainer;
    }

    @Override
    public Bundle getParams() {
        return null;
    }

    @Override
    public DialogManager getDialogManager() {
        return containerDelegate.getDialogManager();
    }

    @Override
    public DialogManager createDialogManager() {
        return containerDelegate.createDefaultDialogManager();
    }

    protected abstract VM createViewData();

    protected abstract P createPresenter();

    protected abstract VH createViewHelper();

    protected void initAttributes(AttributeSet attrs) {
        //do nothing
    }

    protected DependencyProvider getDependencyProvider() {
        return getScreen().getDependencyProvider();
    }
}
