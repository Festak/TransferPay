package com.istatkevich.cmvp.core.container;

import android.content.Context;
import android.os.Bundle;

import com.istatkevich.cmvp.core.dialog.DialogManager;
import com.istatkevich.cmvp.core.presenter.Presenter;
import com.istatkevich.cmvp.core.viewhelper.ViewHelper;
import com.istatkevich.cmvp.core.viewmodel.ViewModel;

/**
 * Created by Ivan on 18.06.2017.
 */

public class BaseContainerDelegate<VM extends ViewModel, VH extends ViewHelper<P, ?>, P extends Presenter>
        implements ContainerDelegate<VM, VH, P> {

    private ActivityContainer activityContainer;

    private VM viewModel;
    private VH viewHelper;
    private P presenter;

    private DialogManager dialogManager;

    public BaseContainerDelegate(ActivityContainer activityContainer) {
        this.activityContainer = activityContainer;
    }

    @Override
    public void onViewModelCreated(VM viewModel, Bundle savedInstanceState) {
        viewModel.onCreate(savedInstanceState);
        this.viewModel = viewModel;
    }

    @Override
    public void onViewHelperCreated(Context context, VH viewHelper) {
        this.viewHelper = viewHelper;
        this.viewHelper.inflate(context);
    }

    @Override
    public void onPresenterCreated(P presenter, String containerId) {
        this.viewHelper.injectDependencies(activityContainer, presenter);
        this.presenter = presenter;

        preparePresenter(containerId);
    }

    @Override
    public void onDialogManagerCreated(DialogManager dialogManager) {
        this.dialogManager = dialogManager;
    }

    @Override
    public DialogManager createDefaultDialogManager() {
        return new DialogManager(
                activityContainer,
                viewModel,
                presenter
        );
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        viewModel.onSaveInstanceState(outState);
    }

    @Override
    public void onDestroy() {
        presenter.onDestroy();
        dialogManager.onDestroy();
    }

    @Override
    public VM getViewModel() {
        return viewModel;
    }

    @Override
    public VH getViewHelper() {
        return viewHelper;
    }

    @Override
    public P getPresenter() {
        return presenter;
    }

    @Override
    public DialogManager getDialogManager() {
        return dialogManager;
    }

    private void preparePresenter(String containerId) {
        presenter.injectDependencies(activityContainer, viewModel, viewHelper);
        activityContainer.registerPresenter(containerId, presenter);
        activityContainer.registerPermissionObserver(containerId, presenter);
        activityContainer.registerLifecycleListener(presenter);
    }
}
