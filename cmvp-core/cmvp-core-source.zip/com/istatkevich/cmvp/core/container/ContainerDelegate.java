package com.istatkevich.cmvp.core.container;

import android.content.Context;
import android.os.Bundle;

import com.istatkevich.cmvp.core.dialog.DialogManager;
import com.istatkevich.cmvp.core.presenter.Presenter;
import com.istatkevich.cmvp.core.viewhelper.ViewHelper;
import com.istatkevich.cmvp.core.viewmodel.ViewModel;

/**
 * Created by Ivan on 18.06.2017.
 */

public interface ContainerDelegate<VM extends ViewModel, VH extends ViewHelper<P, ?>, P extends Presenter> {

    void onViewModelCreated(VM viewModel, Bundle savedInstanceState);

    void onViewHelperCreated(Context context, VH viewHelper);

    void onPresenterCreated(P presenter, String containerId);

    void onDialogManagerCreated(DialogManager dialogManager);

    DialogManager createDefaultDialogManager();

    void onSaveInstanceState(Bundle outState);

    void onDestroy();

    VM getViewModel();

    VH getViewHelper();

    P getPresenter();

    DialogManager getDialogManager();
}
