package com.istatkevich.cmvp.core.container;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.CallSuper;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;

import com.istatkevich.cmvp.core.ActivityLifecycleListener;
import com.istatkevich.cmvp.core.ActivityLifecycleManager;
import com.istatkevich.cmvp.core.BackStackListener;
import com.istatkevich.cmvp.core.BackStackManager;
import com.istatkevich.cmvp.core.DependencyProvider;
import com.istatkevich.cmvp.core.HideKeyboard;
import com.istatkevich.cmvp.core.R;
import com.istatkevich.cmvp.core.router.Router;
import com.istatkevich.cmvp.core.Screen;
import com.istatkevich.cmvp.core.dialog.DialogManager;
import com.istatkevich.cmvp.core.permissionmanager.PermissionManager;
import com.istatkevich.cmvp.core.permissionmanager.PermissionObserver;
import com.istatkevich.cmvp.core.permissionmanager.PermissionRationaleRepresenter;
import com.istatkevich.cmvp.core.presenter.Presenter;
import com.istatkevich.cmvp.core.progressoverlay.Progress;
import com.istatkevich.cmvp.core.progressoverlay.ProgressOverlay;
import com.istatkevich.cmvp.core.viewmodel.ViewModel;
import com.istatkevich.cmvp.core.viewhelper.ViewHelper;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;


/**
 * Created by i.statkevich on 07.10.2015.
 */
public abstract class ActivityContainer<VM extends ViewModel, VH extends ViewHelper<P, ?>, P extends Presenter>
        extends
        AppCompatActivity

        implements
        Container,
        Screen,
        Progress,
        HideKeyboard,
        PermissionRationaleRepresenter {

    public static final int ACTIVITIES_CODE_UNDEFINED = -1;
    public static final String FIELD_PARENT_ACTIVITY_CODE = "parent_activity_code";

    private static final int REQUEST_CODE_PERMISSION = 47529;

    private ContainerDelegate<VM, VH, P> containerDelegate;
    private Router router;

    private ActivityLifecycleManager activityLifecycleManager;
    private Map<String, Presenter> presenterMap;
    private BackStackManager backStackManager;
    //private DialogManager dialogManager;

    private Progress progressOverlay;

    private boolean activityRecreated;
    private int parentActivityCode;

    private PermissionManager permissionManager;
    private DependencyProvider dependencyProvider;

    public ActivityContainer() {
        dependencyProvider = DependencyProvider.getInstance();
        containerDelegate = new BaseContainerDelegate<>(this);
    }

    @Override
    public void registerPermissionObserver(String observerId, PermissionObserver permissionObserver) {
        permissionManager.registerPermissionObserver(observerId, permissionObserver);
    }

    @Override
    public void unregisterPermissionObserver(String observerId) {
        permissionManager.unregisterPermissionObserver(observerId);
    }

    @Override
    public void onShowPermissionRationale(String[] permissionsDenied, String[] permissionsDontAskAgain) {
        String message = getString(R.string.permission_rationale_message) + " \n\n" + Arrays.toString(permissionsDenied);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(R.string.permission_rationale_title);
        builder.setMessage(message);
        builder.setCancelable(false);
        builder.setPositiveButton(R.string.permission_rationale_button, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                permissionManager.onRationaleCompleted();
            }
        });

        builder.create().show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        permissionManager.onProcessRequestResult(requestCode, permissions, grantResults);
    }

    @Override
    public void registerPresenter(String containerId, Presenter presenter) {
        presenterMap.put(containerId, presenter);
    }

    @Override
    public void unregisterPresenter(String containerId) {
        presenterMap.remove(containerId);
    }

    @Override
    public void registerLifecycleListener(ActivityLifecycleListener listener) {
        activityLifecycleManager.add(listener);
    }

    @Override
    public void unregisterLifecycleListener(ActivityLifecycleListener listener) {
        if (activityLifecycleManager == null) {
            return;
        }

        activityLifecycleManager.remove(listener);
    }

    @Override
    public Screen getScreen() {
        return this;
    }

    @Override
    public DialogManager getDialogManager() {
        return containerDelegate.getDialogManager();
    }

    @Override
    public DialogManager createDialogManager() {
        return containerDelegate.createDefaultDialogManager();
    }

    @Override
    public Bundle getParams() {
        return getIntent().getExtras();
    }

    @SuppressWarnings("unchecked")
    @Override
    public <T> T getPresenter(String containerId, Class<T> presenterClass) {
        return (T) presenterMap.get(containerId);
    }

    public P getScreenPresenter() {
        return containerDelegate.getPresenter();
    }

    public Map<String, Presenter> getPresenters() {
        return presenterMap;
    }

    public VM getViewModel() {
        return containerDelegate.getViewModel();
    }

    @Override
    @SuppressWarnings("unsuspeckted")
    public <R> R getRouter(Class<R> routerClass) {
        return (R) router;
    }

    @Override
    public void closeScreen() {
        finish();
    }

    @Override
    public void closeScreen(int resultCode, Intent data) {
        setResult(resultCode, data);
        finish();
    }

    @Override
    public DependencyProvider getDependencyProvider() {
        return dependencyProvider;
    }

    public VH getViewHelper() {
        return containerDelegate.getViewHelper();
    }

    public int getParentActivityCode() {
        return parentActivityCode;
    }

    @Override
    public boolean isRecreated() {
        return activityRecreated;
    }

    @Override
    public void showProgress() {
        showProgress(null);
    }

    @Override
    public void showProgress(String message) {
        hideKeyboard();
        progressOverlay.showProgress(message);
    }

    @Override
    public void setProgressMessage(String message) {
        progressOverlay.setProgressMessage(message);
    }

    @Override
    public void hideProgress() {
        progressOverlay.hideProgress();
    }

    @Override
    public void hideProgressMessage() {
        progressOverlay.hideProgressMessage();
    }

    @Override
    public boolean isProgressVisible() {
        return progressOverlay != null && progressOverlay.isProgressVisible();
    }

    @Override
    @CallSuper
    public void onBackPressed() {
        if (!backStackManager.userBackPressed()) {
            super.onBackPressed();
        }
    }

    @Override
    public void addToBackStack(BackStackListener backStackListener) {
        backStackManager.add(backStackListener);
    }

    @Override
    public void removeFromBackStack(BackStackListener backStackListener) {
        backStackManager.remove(backStackListener);
    }

    @Override
    public void setActionBarTitle(String title) {
        // do nothing
    }

    /**
     * Hides keyboard.
     * Use this method before onStop()
     */
    @Override
    public void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);

        imm.hideSoftInputFromWindow(getWindow().getDecorView().getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
    }

    @Override
    @CallSuper
    protected void onCreate(Bundle savedInstanceState) {
        //TODO refactor
        defineActivityRecreated(savedInstanceState);

        activityLifecycleManager = new ActivityLifecycleManager();
        presenterMap = new HashMap<>();
        permissionManager = new PermissionManager(this, REQUEST_CODE_PERMISSION, this);
        backStackManager = new BackStackManager();
        router = createRouter();

        Intent intent = getIntent();
        parentActivityCode = intent.getIntExtra(FIELD_PARENT_ACTIVITY_CODE, ACTIVITIES_CODE_UNDEFINED);

        onBeforeCreateMvc(savedInstanceState);

        containerDelegate.onViewModelCreated(createViewModel(), savedInstanceState);

        super.onCreate(savedInstanceState);

        containerDelegate.onViewHelperCreated(this, createViewHelper());
        setContentView(containerDelegate.getViewHelper().getRoot());

        addProgress();

        containerDelegate.onPresenterCreated(createPresenter(), getContainerId());
        containerDelegate.onDialogManagerCreated(createDialogManager());
    }

    @Override
    protected void onStart() {
        super.onStart();
        activityLifecycleManager.onActivityStart();
        permissionManager.onActivityStart();
    }

    @Override
    @CallSuper
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        activityLifecycleManager.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    protected void onResume() {
        super.onResume();
        activityLifecycleManager.onActivityResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        activityLifecycleManager.onActivityPause();

        if (isFinishing()) {
            release();
        }
    }

    @Override
    @CallSuper
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);

        containerDelegate.onSaveInstanceState(outState);
    }

    @Override
    protected void onStop() {
        super.onStop();

        if (activityLifecycleManager != null) {
            activityLifecycleManager.onActivityStop();
        }
    }

    protected abstract VM createViewModel();

    protected abstract P createPresenter();

    protected abstract VH createViewHelper();

    protected abstract Router createRouter();

    protected void onBeforeCreateMvc(Bundle savedInstanceState) {
        //Do nothing
    }

    protected void defineActivityRecreated(Bundle savedInstanceState) {
        if (savedInstanceState != null) {
            activityRecreated = true;
        }
    }

    protected void addProgress() {
        ViewGroup rootView = (ViewGroup) this.findViewById(android.R.id.content);

        if (rootView != null && progressOverlay == null) {
            progressOverlay = new ProgressOverlay(this);
            rootView.addView((ProgressOverlay) progressOverlay);
        }
    }

    private void release() {
        containerDelegate.onDestroy();

        activityLifecycleManager.release();
        activityLifecycleManager = null;

        permissionManager.release();

        dependencyProvider.releaseActivityScope();
        dependencyProvider = null;
    }
}
