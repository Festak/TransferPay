package com.istatkevich.cmvp.core.container;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.CallSuper;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.istatkevich.cmvp.core.DependencyProvider;
import com.istatkevich.cmvp.core.Screen;
import com.istatkevich.cmvp.core.dialog.DialogManager;
import com.istatkevich.cmvp.core.presenter.Presenter;
import com.istatkevich.cmvp.core.viewhelper.ViewHelper;
import com.istatkevich.cmvp.core.viewmodel.ViewModel;

/**
 * Created by i.statkevich on 09.10.2015.
 */
public abstract class FragmentContainer<VM extends ViewModel, VH extends ViewHelper<P, ?>, P extends Presenter>
        extends Fragment
        implements Container {

    private ContainerDelegate<VM, VH, P> containerDelegate;
    private ActivityContainer activityContainer;

    private boolean fragmentRecreated;

    @Override
    @CallSuper
    public void onAttach(Context context) {
        super.onAttach(context);

        Activity activity = getActivity();

        if (activity instanceof ActivityContainer) {
            this.activityContainer = (ActivityContainer) activity;
        } else {
            throw new ClassCastException("The parent activity must be instance of ActivityContainer");
        }
    }

    @Nullable
    @Override
    @CallSuper
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);

        if (savedInstanceState != null) {
            fragmentRecreated = true;
        }

        containerDelegate = new BaseContainerDelegate<>(activityContainer);
        containerDelegate.onViewHelperCreated(getContext(), createViewHelper());

        return containerDelegate.getViewHelper().getRoot();
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        containerDelegate.onViewModelCreated(createViewData(), savedInstanceState);
    }

    @Override
    @CallSuper
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        containerDelegate.onSaveInstanceState(outState);
    }

    /**
     * Called when fragment was recreated and created before onStart
     *
     * @param savedInstanceState
     */
    @CallSuper
    @Override
    public void onViewStateRestored(@Nullable Bundle savedInstanceState) {
        super.onViewStateRestored(savedInstanceState);

        containerDelegate.onPresenterCreated(createPresenter(), getContainerId());
        containerDelegate.onDialogManagerCreated(createDialogManager());
    }

    @CallSuper
    @Override
    public void onDestroy() {
        super.onDestroy();
        containerDelegate.onDestroy();
    }

    public ActivityContainer getActivityContainer() {
        return activityContainer;
    }

    public VH getViewHelper() {
        return containerDelegate.getViewHelper();
    }

    public P getPresenter() {
        return containerDelegate.getPresenter();
    }

    @Override
    public DialogManager getDialogManager() {
        return containerDelegate.getDialogManager();
    }

    @Override
    public DialogManager createDialogManager() {
        return containerDelegate.createDefaultDialogManager();
    }

    @Override
    public Screen getScreen() {
        return getActivityContainer();
    }

    @Override
    public Bundle getParams() {
        return getArguments();
    }

    public boolean isFragmentRecreated() {
        return fragmentRecreated;
    }

    protected abstract VM createViewData();

    protected abstract P createPresenter();

    protected abstract VH createViewHelper();

    protected DependencyProvider getDependencyProvider() {
        return getScreen().getDependencyProvider();
    }
}
