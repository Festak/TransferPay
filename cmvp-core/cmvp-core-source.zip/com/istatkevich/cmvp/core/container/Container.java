package com.istatkevich.cmvp.core.container;


import android.os.Bundle;

import com.istatkevich.cmvp.core.Screen;
import com.istatkevich.cmvp.core.dialog.DialogManager;

/**
 * Created by i.statkevich on 03.03.2016.
 */
public interface Container {

    DialogManager createDialogManager();

    DialogManager getDialogManager();

    Screen getScreen();

    Bundle getParams();

    String getContainerId();
}
